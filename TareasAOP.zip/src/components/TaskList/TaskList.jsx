import { useState } from 'react';

function TaskList({ tasks, onDeleteTask, onToggleTask, onEditTask }) {
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedText, setEditedText] = useState('');

  const handleEdit = (index, text) => {
    setEditingIndex(index);
    setEditedText(text);
  };

  const saveEdit = (index) => {
    onEditTask(index, editedText);
    setEditingIndex(null);
  };

  return (
    <ul>
      {tasks.map((task, index) => (
        <li key={index}>
          <input
            type="checkbox"
            checked={task.completed}
            onChange={() => onToggleTask(index)}
          />
          {editingIndex === index ? (
            <input
              type="text"
              value={editedText}
              onChange={(e) => setEditedText(e.target.value)}
              onBlur={() => saveEdit(index)}
              onKeyPress={(e) => e.key === 'Enter' && saveEdit(index)}
            />
          ) : (
            <span
              style={{
                textDecoration: task.completed ? 'line-through' : 'none',
              }}
              onClick={() => handleEdit(index, task.text)}  // Con este evento llamamos a la funcion que nos permite editarla
            >
              {task.text}
            </span>
          )}
          <button onClick={() => onDeleteTask(index)}>Eliminar</button>
        </li>
      ))}
    </ul>
  );
}

export default TaskList;