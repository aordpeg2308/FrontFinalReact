function TaskFilter({ filter, setFilter }) {
    return ( //Aqui creo un componente que imprimira los botones que harán la busqueda por el filtado
      <div className="task-filter">
        <button
          onClick={() => setFilter('all')}
          className={filter === 'all' ? 'active' : ''} //Con el active lo que hacemos es que si el valor de busqueda es igual al del botón este boron saldra de color azul ;P
        >
          Todas
        </button>
        <button
          onClick={() => setFilter('active')}
          className={filter === 'active' ? 'active' : ''}
        >
          Activas
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={filter === 'completed' ? 'active' : ''}
        >
          Completadas
        </button>
      </div>
    );
  }
  
  export default TaskFilter;