import { useState, useEffect } from 'react';
import TaskForm from './components/TaskForm/TaskForm'; 
import TaskList from './components/TaskList/TaskList'; 
import TaskFilter from './components/TaskFilter/TaskFilter'; 
import './App.css';

function App() { 
  //El primer paso es pillar las tareas desde el localStorage
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem('tasks');
    return savedTasks ? JSON.parse(savedTasks) : [];
  });

  
  const [filter, setFilter] = useState('all');


  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

 
  const addTask = (text) => {
    setTasks([...tasks, { text, completed: false }]);
  };

 
  const deleteTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

 
  const toggleTask = (index) => {
    setTasks(tasks.map((task, i) =>
      i === index ? { ...task, completed: !task.completed } : task
    ));
  };

 
  const editTask = (index, newText) => {
    setTasks(tasks.map((task, i) =>
      i === index ? { ...task, text: newText } : task
    ));
  };

  //Aqui devolvemos todas las tareas dependiendo del filtro
  const filteredTasks = tasks.filter(task => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true; 
  });

  return (
    <div className="app">
      <h1>Gestión de Tareas - 2º DAW</h1>
      
      <TaskForm onAddTask={addTask} />
      
      <TaskFilter filter={filter} setFilter={setFilter} />
     
      <TaskList
        tasks={filteredTasks}
        onDeleteTask={deleteTask}
        onToggleTask={toggleTask}
        onEditTask={editTask}
      />
    </div>
  );
}

export default App;